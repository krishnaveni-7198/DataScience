import numpy as np
a3d_array=np.array([[[1.1,2.1],[3.1,4.1]],[[5.1,6.1],[7.1,8.1]]],dtype=float)
print(a3d_array)