import numpy as np
a = np.arange(1, 11, 1)
print(a)
first_element = a[:4]
print(first_element)
first_element1 = a[5:]
print(first_element1)
first_element2 = a[1:7]
print(first_element2)