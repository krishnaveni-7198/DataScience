import numpy as np
x=np.empty([2, 2])
print(x)
y=np.full((2, 2), 1)
print(y)
z=np.full((2, 2), 0)
print(z)
